@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Please install Node.js 20+ from https://nodejs.org/ or open shot.html directly.
  pause
  exit /b 1
)
node -e "if (Number(process.versions.node.split('.')[0]) < 20) { console.error('Node.js 20+ required'); process.exit(1); }"
if errorlevel 1 (
  pause
  exit /b 1
)
if not defined PORT set PORT=3000
echo Open http://127.0.0.1:%PORT% in your browser. Ctrl+C to stop.
node server.mjs
pause
