#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Please install Node.js 20+ from https://nodejs.org/ or open shot.html directly."
  exit 1
fi
node -e 'if (Number(process.versions.node.split(".")[0]) < 20) { console.error("Node.js 20+ required"); process.exit(1); }'
echo "Open http://127.0.0.1:${PORT:-3000} in your browser. Ctrl+C to stop."
exec node server.mjs
